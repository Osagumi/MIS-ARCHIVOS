#Forma05.py
from random import *
def main():
        num = leeNumero() #(2 pto.)
        Tupla = creaTupla(num) #(3 Ptos.)
        imprimeResultado(num,Tupla) #(1 Pto.)
#

def leeNumero():
        verificador = True
        while verificador:
                num = input("Ingrese numero entero entre 100 y 200: ")
                if num.isdigit():
                        if int(num) < 100:
                                print("ingreso un numero menor a 100")
                                verificador = True
                        elif int(num) > 200:
                                print("ingreso un numero mayor a 200")
                                verificador = True
                        elif int(num) < 0:
                                print("ingreso algo distinto a un numero o ingreso un numero negativo")
                                verificador = True
                        else:
                                return int(num)
                                verificador = False
                        
                elif num.isspace():
                        print("No ingreso nada, o ingreso espacios")
                        verificador = True
                        
                        
                else:
                        print("ingreso algo distinto a un numero o ingreso un numero negativo")
                        verificador = True



def creaTupla(num):
        cadena = ""
        lista = []
        contador = 0
        while contador != 10:
                x = randrange(20, num)
                if (x % 2 == 0) and (not(x in lista)) and (sumadigitos(x)>5):
                        cadena = cadena + " " + str(x)
                        lista.append(x)
                        contador += 1
        
        cf = cadena.lstrip()
        p = cf.find(' ')
        t = tuple()
        while(p != -1):
                t = t + (cf[:p],)
                cf = cf[p+1:].strip()
                p = cf.find(' ')
        t = t + (cf,)   
        return t

def imprimeResultado(x,y):
        print("numero escogido: {}".format(x))
        print("la tupla: {}".format(y))
        
                

def sumadigitos(x):
        dts = str(x)
        newnum=0
        for i in dts:
                newnum = newnum + int(i)

        return newnum
                

        
                

main()


                                        
                        
                
        
        
        
                
                
